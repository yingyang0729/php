<?php
// This is a single line comment.

/*
This is a 
multi-line comment.
*/
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sanchez&display=swap" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet" type="text/css">
    <title>Welcome to week 8</title>
</head>
<body>
    <h1 class="hidden">Welcome to PHP</h1>
    <a class="hidden" href="#content">Skip to content</a>
    <header>
    </header>
    <main id="content">
        
        <section>
           <!-----<p>Hello World!</p>---------------> 
           <p>Hello World!</p>
        </section>
        <h2>Integers</h2>
        <p>
             <br>
            <?php
                $int1 = 12;
                $int2 = 12;
                $problem = ($int1 * $int2) - 12 * 4;
                echo "Yup, look mom I can do math! {$problem}";
            ?>
        </p>


        <h2>Integers & Functions</h2>
        <p>
            <br>
            <?php
               
                echo "Exponential:".pow(9,250). "<br>";
                echo "Random:".rand()."<br>";
                echo "Control Random:".rand(1,100)."<br>";
            ?>
        </p>

        
        <h2>Increments and Decrements</h2>
        <p>
            <br>
            <?php
               $int3 = 20;
               $int4 = 3;

               echo $int3+=2;
               echo "<br>";
               echo $int3-=4;
               echo "<br>";
               echo $int3*=1.13;
               echo "<br>";
               echo $int3/=2;
               echo "<br>";
               $int4++;
               echo $int4;
               echo "<br>";
               echo "Round:".round($int3,1);
               echo "<br>";
               echo "Round: ceil".ceil($int3);

               echo "<br>";
               echo "Round: floor".floor($int3);
            ?>
        </p>
     

        <h2>Arrays</h2>
        <p>
             <br>
            <?php
                $numbers = array(4,12,24,30);
                // $numbers = [1,2,3];short hand
                echo $numbers[0];
                echo "<br>";
                $sandbox = array(6,"New York", array(1,2,3));
                echo "<br>";
                echo $sandbox[1];
                echo "<br>";
                echo $sandbox[2][1];
                echo "<br>";
                echo print_r($sandbox); //be careful with this !!


            ?>
        </p>


        
        <h2>Assoc Arrays</h2>
        <p>
             <br>
            <?php
                $assoc = array("fname"=>"First Name","lname"=>"Last Name");
                echo $assoc["fname"]." ".$assoc["lname"];
            ?>
        </p>
      

                
        <h2>Assoc function</h2>
        <p>
             <br>
            <?php
                $numbersArray = array(12,4,30,24,16);
                echo print_r($numbersArray)."<br>";
                array_push($numbersArray, 55);
                echo print_r($numbersArray)."<br>";
                echo count($numbersArray)."<br>";
                echo max($numbersArray)."<br>";
                echo min($numbersArray)."<br>";
                sort($numbersArray);
                echo print_r($numbersArray)."<br>";//give it an order
                rsort($numbersArray);
                echo print_r($numbersArray)."<br>";//a new order for the number
                echo "Implode: ".$string = implode("," ,$numbersArray);
            ?>
        </p>


        <h2>Booleans</h2>
        <p>
             <br>
            <?php
               $test1 = true;
               $test2 = false;
               echo "True: ".$test1."<br>";
               echo "False: ".$test2."<br>";

            ?>
        </p>

        <h2>Null/Isset/Empty</h2>
        <p>
             <br>
            <?php
               $test1 = null;
               $test2 = "";
               // if true,1
               //if false, nothing
               echo "Test 1(null): ".is_null($test1)."<br>";
               echo "Test 2(\"\"): ".is_null($test2)."<br>";
               echo "Test 3(undefined): ".is_null($test3)."<br>";
               // Isset
               echo "Test 4(null): ".isset($test1)."<br>";
               echo "Test 5(\"\"): ".isset($test2)."<br>";
               echo "Test 6(undefined): ".isset($test3)."<br>";

               //if test1=0, the isset will be  1 as the result of every setence

               //empty
               // 0,0.0,"0" comes back as empty
               $test3 = "none";
               echo "Test 7(null): ".empty($test1)."<br>";
               echo "Test 8(\"\"): ".empty($test2)."<br>";
               echo "Test 9(): ".empty($test3)."<br>";
            ?>
        </p>


        <h2>Type Casting</h2>
        <p>
             <br>
            <?php
               $number = 10;
               echo gettype($numbers)."<br>";
               $text = "Monday night Football";
               echo gettype($text)."<br>";
               $num = "10";
               echo gettype($num)."<br>";
               settype($num,"int");
               echo gettype($num)."<br>";
               
            ?>
        </p>
        
        <h2>Conditions</h2>
        <p>
             <br>/
            <?php
               $one = 4;
               $two = 6;

               if($one < $two){
                    echo "Is it really....";

               }else if(0){
                    echo "Maybe....";
               }else{
                    echo "they are equal";
               }
               
            ?>
        </p>
        
        <h2>Operators</h2>
        <p>
             <br>
            <?php

               /* 

               Assign: =
               Equal to: ==
               Identical to: ===
               Compare: >< >= <= <>
               Not Equal: !=
               Not Identical: !==

               Logical 
               And &&
               Or 
               Not
               */
            ?>
        </p>
       
        
        <h2>Switch Statement</h2>
        <p>
             <br>
            <?php
               
               $testcase = 99;
               
               switch($testcase) {
                case 0:
                    echo"Testcase is 0<br>";
                    break;
                case 25;
                    echo"Testcase is 25<br>";
                    break;
                case 75:
                    echo"Testcase is 75<br>";
                    break;
                case 99:
                case 100:
                    echo"Testcase is 99 or 100<br>";
                    break;

                    
               }

            
            ?>
        </p>

    </main>
    <footer>
       
    </footer>
</body>
</html>