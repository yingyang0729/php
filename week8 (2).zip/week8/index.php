<?php
// This is a single line comment.

/*
This is a 
multi-line comment.
*/
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sanchez&display=swap" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet" type="text/css">
    <title>Welcome to week 8</title>
</head>
<body>
    <h1 class="hidden">Welcome to PHP</h1>
    <a class="hidden" href="#content">Skip to content</a>
    <header>
    </header>
    <main id="content">
        
        <section>
           <!-----<p>Hello World!</p>---------------> 
           <p>Hello World!</p>
        </section>
        <h2>Strings</h2>
        <p>
            a:) building up a string <br>
            <?php
            $fname = "Bilbo";
            $lname = "Baggins";
            echo $fname;
            echo "&nbsp;";
            echo $lname;
            ?>
        </p>


        
     
        <p>
            b:) Concat <br>
            <?php
            $fname = "Gandalf";
            $lname = "The Gray";
            echo $fname."&nbsp;" .$lname;
            ?>
        </p>

        <p>
            b:) Combination and Sub <br>
            <?php
            $fname = "Frodo";
            $lname = "Baggins";
            $fullname = $fname."&nbsp;".$lname;
            echo $fullname;
            echo "&nbsp;";
            echo "{$fname}&nbsp;{$lname}";
            echo "<h3 class='title'>{$fname}&nbsp;{$lname}</h3>";
            echo "<h3 class=\"title\">{$fname}&nbsp;{$lname}</h3>";
            ?>
        </p>

        <h2>Strings & Functions</h2>
        <p>
            a:) building up a string <br>
            <?php
                $part1 = "The quick brown fox";
                $part2 = "jumped over the lazy dog";
                $part3 = $part1;
                echo $part3 .= $part2;            
            ?>
        </p>

        <p>
            b:) word Wrap <br>
            <?php
                $content = "The quick brown fox jumped over the lazy dog.";
                $newcontent = wordwrap($content, 20, "<br>");
                echo $newcontent;
                
                           
            ?>
        </p>

        <p>
            C:) Character Case <br>
            <?php
                
                echo strtolower($content)."<br>";

                echo strtoupper($content)."<br>";
                
                echo ucfirst($content)."<br>";    

                echo ucwords($content)."<br>";           
            ?>
        </p>

        <p>
            d:) Working with strings <br>
            <?php
                
                echo "Length: ".strlen($content)."<br>"; //know the length of the string(the length of the sentence)
                echo "Find: ".strstr($content,"lazy")."<br>";
                echo "Replace: ".str_replace("lazy","agressive",$content);

            ?>
        </p>

    </main>
    <footer>
       
    </footer>
</body>
</html>